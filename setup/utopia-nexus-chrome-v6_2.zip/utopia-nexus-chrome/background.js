// Background service worker for Utopia Nexus Intel (Chrome MV3)
// Handles storage get/set messages from content script

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "storage_get") {
    chrome.storage.local.get(message.keys, (result) => {
      sendResponse({ data: result });
    });
    return true; // Keep channel open for async response
  }

  if (message.type === "storage_set") {
    chrome.storage.local.set(message.data, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});
